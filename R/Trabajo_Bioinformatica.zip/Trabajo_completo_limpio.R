datos <- read.table(
  "C:/Users/ellya/Downloads/Trabajo FINAL de R-20261029 (1)/archivo-entrada.txt",
  header = TRUE,
  sep = "\t",
  check.names = FALSE,
  stringsAsFactors = FALSE
)

head(datos)
tail(datos)
dim(datos)
colnames(datos)

columnas_control <- c(
  "C2-TPM",
  "C1-TPM",
  "C3-TPM"
)

columnas_condicion <- c(
  "1W5-TPM",
  "1W6-TPM",
  "1W5-COV"
)

control <- datos[, columnas_control]

condicion <- datos[, columnas_condicion]

datos$media_Control <- rowMeans(control)

datos$DE_Control <- apply(control, 1, sd)

datos$media_Condicion <- rowMeans(condicion)

datos$DE_Condicion <- apply(condicion, 1, sd)

# Colores del trabajo

color_control <- "skyblue"
color_condicion <- "salmon"

# Histograma de las medias

png(
  "histogramas_medias.png",
  width = 1600,
  height = 800,
  res = 150
)

par(mfrow = c(1, 2))

hist(
  datos$media_Control,
  col = color_control,
  border = "white",
  main = "Media de expresión: Control",
  xlab = "Media TPM",
  ylab = "Número de genes"
)

hist(
  datos$media_Condicion,
  col = color_condicion,
  border = "white",
  main = "Media de expresión: Condición",
  xlab = "Media TPM",
  ylab = "Número de genes"
)

par(mfrow = c(1, 1))

dev.off()

# Boxplot de Control y Condición

valores_boxplot <- c(
  as.numeric(as.matrix(control)),
  as.numeric(as.matrix(condicion))
)

grupo_boxplot <- factor(
  c(
    rep("Control", length(as.matrix(control))),
    rep("Condición", length(as.matrix(condicion)))
  ),
  levels = c("Control", "Condición")
)

# Transformación para que los valores extremos no oculten las cajas

valores_boxplot_log <- log2(valores_boxplot + 1)

png(
  "boxplot_control_condicion.png",
  width = 1000,
  height = 800,
  res = 150
)

boxplot(
  valores_boxplot_log ~ grupo_boxplot,
  col = c(color_control, color_condicion),
  main = "Expresión génica: Control frente a Condición",
  xlab = "Grupo",
  ylab = "log2(TPM + 1)"
)

legend(
  "topleft",
  legend = c("Control", "Condición"),
  fill = c(color_control, color_condicion),
  bty = "n"
)

dev.off()
# Evaluación de normalidad y comparación estadística

shapiro_p <- function(x) {
  
  if (length(unique(x)) < 3) {
    return(NA)
  }
  
  shapiro.test(x)$p.value
}

p_valores <- numeric(nrow(datos))

test_utilizado <- character(nrow(datos))

p_normalidad_Control <- numeric(nrow(datos))

p_normalidad_Condicion <- numeric(nrow(datos))

for (i in 1:nrow(datos)) {
  
  x <- as.numeric(control[i, ])
  y <- as.numeric(condicion[i, ])
  
  p_control <- shapiro_p(x)
  p_condicion <- shapiro_p(y)
  
  if (is.na(p_control)) {
    p_control <- 0
  }
  
  if (is.na(p_condicion)) {
    p_condicion <- 0
  }
  
  p_normalidad_Control[i] <- p_control
  p_normalidad_Condicion[i] <- p_condicion
  
  if (p_control > 0.05 && p_condicion > 0.05) {
    
    prueba <- t.test(
      x,
      y,
      var.equal = FALSE
    )
    
    p_valores[i] <- prueba$p.value
    test_utilizado[i] <- "t de Welch"
    
  } else {
    
    prueba <- wilcox.test(
      x,
      y,
      exact = FALSE
    )
    
    p_valores[i] <- prueba$p.value
    test_utilizado[i] <- "Wilcoxon"
  }
}

datos$p_value <- p_valores

datos$test_utilizado <- test_utilizado

datos$p_normalidad_Control <- p_normalidad_Control

datos$p_normalidad_Condicion <- p_normalidad_Condicion

# Genes diferencialmente expresados

genes_DE <- datos[
  datos$p_value < 0.05,
]

genes_DE$direccion <- ifelse(
  genes_DE$media_Condicion > genes_DE$media_Control,
  "Sobreexpresado",
  "Reprimido"
)

numero_genes_DE <- nrow(genes_DE)

cat(
  "Genes diferencialmente expresados:",
  numero_genes_DE,
  "\n"
)

cat(
  "Genes sobreexpresados:",
  sum(genes_DE$direccion == "Sobreexpresado"),
  "\n"
)

cat(
  "Genes reprimidos:",
  sum(genes_DE$direccion == "Reprimido"),
  "\n"
)

write.table(
  genes_DE,
  "genes_diferencialmente_expresados.txt",
  sep = "\t",
  row.names = FALSE,
  quote = FALSE
)

# Heatmap de los genes diferencialmente expresados

library(pheatmap)

if (nrow(genes_DE) > 0) {
  
  matriz_heatmap <- as.matrix(
    genes_DE[, c(
      columnas_control,
      columnas_condicion
    )]
  )
  
  rownames(matriz_heatmap) <- make.unique(
    as.character(genes_DE[["Gene Name"]])
  )
  
  matriz_log <- log2(matriz_heatmap + 1)
  
  matriz_z <- t(
    scale(t(matriz_log))
  )
  
  matriz_z[is.na(matriz_z)] <- 0
  
  anotacion_columnas <- data.frame(
    Grupo = factor(
      c(
        "Control",
        "Control",
        "Control",
        "Condición",
        "Condición",
        "Condición"
      ),
      levels = c("Control", "Condición")
    )
  )
  
  rownames(anotacion_columnas) <- colnames(matriz_z)
  
  png(
    "heatmap_genes_diferencialmente_expresados.png",
    width = 1400,
    height = 1200,
    res = 150
  )
  
  pheatmap(
    matriz_z,
    color = colorRampPalette(
      c("blue", "white", "red")
    )(100),
    cluster_rows = TRUE,
    cluster_cols = TRUE,
    annotation_col = anotacion_columnas,
    main = "Genes diferencialmente expresados",
    fontsize_row = 6,
    border_color = NA
  )
  
  dev.off()
}

# Guardar la tabla completa con todos los resultados

write.table(
  datos,
  "tabla_final_con_resultados.txt",
  sep = "\t",
  row.names = FALSE,
  quote = FALSE
)
 


